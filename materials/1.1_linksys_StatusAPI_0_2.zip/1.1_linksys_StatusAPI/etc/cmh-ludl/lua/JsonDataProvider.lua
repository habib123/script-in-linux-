require ("DataProvider")
require ("UdpSender")
require 'lfs'
JSON = require ("JSON") -- one-time load of the routines

JsonDataProvider=
{  
  -- paths
  PATH_EVENT_SRV_FOLDER = "/tmp/prosol/events/srv", -- folder of events for srv
  
  -- network
  SB_IP = "192.168.81.2",
  SB_PORT = "1203",
  
  LS_UDP_REC_PORT = "1202",
  LS_UDP_REC_IP = "192.168.81.255",  
  
  inherit = function(self, debugLevel)
    self.debugLevel = debugLevel
    
    self.sbUdpSender = UdpSender.new(JsonDataProvider.SB_IP, JsonDataProvider.SB_PORT, 0)
    self.lsUdpSender = UdpSender.new(JsonDataProvider.LS_UDP_REC_IP,JsonDataProvider.LS_UDP_REC_PORT,0)
    
        
    --- Initializes the created object
    local super_init = self.Init
    self.Init = function()
    end
    
    
    
    --- Sets the setpoint for charging power
		-- @param setPoint The setpoint to set for batteries charging power
    local super_SetSetpointForChargingPower = self.SetSetpointForChargingPower
    self.SetSetpointForChargingPower = function(setPoint)      
      self.Debug("SetSetpointForChargingPower", 1)
      
      local retval = true
      
      -- send to eaton
      self.sbUdpSender.SendMessage("C24:"..setPoint)
      
      -- send to local 
      self.lsUdpSender.SendMessage("C24:"..setPoint)
      self.lsUdpSender.SendMessage("C23:0")
      
      return retval	
    end
    
    
    
    --- Sets the setpoint for discharging power
		-- @param setPoint The setpoint to set for batteries discharging power
    local super_SetSetpointForDischargingPower = self.SetSetpointForDischargingPower
    self.SetSetpointForDischargingPower = function(setPoint)      
      self.Debug("SetSetpointForDischargingPower", 1)
      
      local retval = true
      
      -- send to eaton
      self.sbUdpSender.SendMessage("C23:"..setPoint)
      
      -- send to local 
      self.lsUdpSender.SendMessage("C23:"..setPoint)
      self.lsUdpSender.SendMessage("C24:0")      
      
      return retval	
    end
    
    --SetPVreductionManually
    --- Sets the step for PV reduction
		-- @param stepID The ID to set set the reduction step
    local super_SetPVreductionManually = self.SetPVreductionManually
    self.SetPVreductionManually = function(reductionStep)      
      self.Debug("SetPVreductionManually", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("C28:"..reductionStep)
      self.lsUdpSender.SendMessage("C28:"..reductionStep)
      
      return retval
    end
    
    
    --SetDeleteSDCardNow 
    --- sets the bool to delete the old files of the SD Card  
		-- @param bool delete true or false 
    local super_SetDeleteSDCardNow = self.SetDeleteSDCardNow
    self.SetDeleteSDCardNow = function(delete_bool)      
      self.Debug("SetDeleteSDCardNow", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("C30:"..delete_bool)
      self.lsUdpSender.SendMessage("C30:"..delete_bool)
      
      return retval
    end
    
    
    --SetDeleteSDCardMonthly 
    --- sets the bool to delete the old files of the SD Card monthly 
		-- @param bool delete monthly true or false  
    local super_SetDeleteSDCardMonthly = self.SetDeleteSDCardMonthly
    self.SetDeleteSDCardMonthly = function(delete_bool_monthly)      
      self.Debug("SetDeleteSDCardMonthly", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("C31:"..delete_bool_monthly)
      self.lsUdpSender.SendMessage("C31:"..delete_bool_monthly)
      
      return retval
    end
    
    
    --SetUSWeatherPrognosisData 
    --- Sets the weather forecast Data
		-- @param data The forecast Data from the Portal 
    local super_SetUSWeatherPrognosisDATA = self.SetUSWeatherPrognosisDATA
    self.SetUSWeatherPrognosisDATA = function(forecastData)      
      self.Debug("SetUSWeatherPrognosisDATA", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("C35:"..forecastData)
      self.lsUdpSender.SendMessage("C35:"..forecastData)
      
      
      return retval
    end
    
    
    --SetCriticalUpdate PLC 
    --- sets the bool to update the plc if the SD card version is newer than the installed one 
		-- @param bool critical_update_bool true or false  
    local super_SetCriticalUpdate = self.SetCriticalUpdate
    self.SetCriticalUpdate = function(critical_update_bool)      
      self.Debug("SetCriticalUpdate", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("C40:"..critical_update_bool)
      self.lsUdpSender.SendMessage("C40:"..critical_update_bool)
      
      return retval
    end
    
    
     --SetDeleteMinDaySetting 
    --- Sets days to delete files on the plc SD Card
		-- @param int days  
    local super_SetDeleteMinDaySetting = self.SetDeleteMinDaySetting
    self.SetDeleteMinDaySetting = function(delete_day_setting)      
      self.Debug("SetUSWeatherPrognosisSetting", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("S161:"..delete_day_setting)
      
      return retval
    end
    
    
     --SetUSWeatherPrognosisData 
    --- Sets the weather forecast Data
		-- @param data The forecast Data from the Portal 
    local super_SetUSWeatherPrognosisSetting = self.SetUSWeatherPrognosisSetting
    self.SetUSWeatherPrognosisSetting = function(forecast_setting)      
      self.Debug("SetUSWeatherPrognosisSetting", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("S162:"..forecast_setting)
      
      return retval
    end
    
    
    
    
    --- Sets the measured load for a specific line
    -- @param load The measured load
    -- @param line The corresponding line
    self.SetLoadOnLine = function(measuredLoad, line)
      self.Debug("SetLoadOnLine", 1)
      
      
      -- determine identifier for plc import based on line
      local identifierString = ""
      
      if line == 1 then
        identifierString = "C07"
      elseif line == 2 then
        identifierString = "C08"
      elseif line == 3 then
        identifierString = "C09"
      else 
        return false
      end
    
      
      
      local retval = true
      
      -- send to plc 
      self.sbUdpSender.SendMessage(identifierString..":"..measuredLoad)
      self.lsUdpSender.SendMessage(identifierString..":"..measuredLoad)
      
      
      return retval	
    end
  
  
  
    --- Sets the measured production for a specific line
    -- @param load The measured production
    -- @param line The corresponding line    
    self.SetProductionOnLine = function(measuredProduction, line)
      self.Debug("SetProductionOnLine", 1)
      
      
      -- determine identifier for plc import based on line
      local identifierString = ""
      
      if line == 1 then
        identifierString = "C10"
      elseif line == 2 then
        identifierString = "C11"
      elseif line == 3 then
        identifierString = "C12"
      else 
        return false
      end
    
      
      
      local retval = true
      
      -- send to plc 
      self.sbUdpSender.SendMessage(identifierString..":"..measuredProduction)
      self.lsUdpSender.SendMessage(identifierString..":"..measuredProduction)
      
      return retval	
    end
    
    
    
    
    
    --- Sets the operation mode
		-- @param operationMode The operationmode to set for batteriesystem
    local super_SetOperationMode = self.SetOperationMode
    self.SetOperationMode = function(operationMode)      
      self.Debug("SetOperationMode", 1)
      
       local retval = true
      
      self.sbUdpSender.SendMessage("C06:"..operationMode)
      self.lsUdpSender.SendMessage("C06:"..operationMode)
      
      return retval
    end
    
    
    
    --- Sets the automatic cellcarestatus mode
		-- @param automaticCellCareStatus The status for the automatic cellcare to set
    local super_SetAutomaticCellCareStatus = self.SetAutomaticCellCareStatus
    self.SetAutomaticCellCareStatus = function(automaticCellCareStatus)      
      self.Debug("SetAutomaticCellCareStatus", 1)
      
      local retval = true
      
      self.sbUdpSender.SendMessage("S104:"..automaticCellCareStatus)
      self.lsUdpSender.SendMessage("S104:"..automaticCellCareStatus)
      
      return retval
    end
    
    
    
    
    local super_GetVersionData = self.GetVersionData
    self.GetVersionData = function()
      
      local data = nil
      data = self.RequestData()
      
      if data == nil then
        return nil
      end
      
      local versionData = {}
      versionData["S15"] = data["S15"]
      versionData["S16"] = data["S16"]
      versionData["S70"] = data["S70"]
      versionData["S45"] = data["S45"]
      versionData["S66"] = data["S66"]
      versionData["S65"] = tonumber(data["S65"])
      versionData["S69"] = tonumber(data["S69"])
      versionData["S01"] = tonumber(data["S01"])
      
      local raw_json_text = JSON:encode(versionData)

      return raw_json_text
      
    end
  
  
  
    local super_GetBatteryData = self.GetBatteryData
    self.GetBatteryData = function()
      
      local data = nil
      data = self.RequestData()
      
      if data == nil then
        return nil
      end
      
      local batteryData = {}
      
      --[[
      batteryData["M34"] = tonumber(data["M34"])
      batteryData["M35"] = tonumber(data["M35"])
      batteryData["C23"] = tonumber(data["C23"])
      batteryData["C24"] = tonumber(data["C24"])
      batteryData["M30"] = tonumber(data["M30"])
      batteryData["S69"] = tonumber(data["S69"])
      batteryData["M31"] = tonumber(data["M31"])
      batteryData["S65"] = tonumber(data["S65"])
      batteryData["S01"] = tonumber(data["S01"])
      batteryData["S71"] = data["S71"]
      
      -- Lichtblick
      batteryData["M03"] = tonumber(data["M03"])
      batteryData["M04"] = tonumber(data["M04"])
      batteryData["M05"] = tonumber(data["M05"])
      batteryData["M06"] = tonumber(data["M06"])
      batteryData["M07"] = tonumber(data["M07"])
      batteryData["M08"] = tonumber(data["M08"])
      batteryData["M09"] = tonumber(data["M09"])
      batteryData["S07"] = tonumber(data["S07"])
      batteryData["S08"] = tonumber(data["S08"])
      --]]
  
  
  
      -- API 1.5
      batteryData["C06"] = tonumber(data["C06"])
      batteryData["C07"] = tonumber(data["C07"])
      batteryData["C08"] = tonumber(data["C08"])
      batteryData["C09"] = tonumber(data["C09"])
      batteryData["C10"] = tonumber(data["C10"])
      batteryData["C11"] = tonumber(data["C11"])
      batteryData["C12"] = tonumber(data["C12"])
      batteryData["C23"] = tonumber(data["C23"])
      batteryData["C24"] = tonumber(data["C24"])
      
      batteryData["M03"] = tonumber(data["M03"])
      batteryData["M04"] = tonumber(data["M04"])
      batteryData["M05"] = tonumber(data["M05"])
      batteryData["M06"] = tonumber(data["M06"])
      batteryData["M07"] = tonumber(data["M07"])
      batteryData["M08"] = tonumber(data["M08"])
      batteryData["M09"] = tonumber(data["M09"])
      batteryData["M30"] = tonumber(data["M30"])
      batteryData["M31"] = tonumber(data["M31"])
      batteryData["M34"] = tonumber(data["M34"])
      batteryData["M35"] = tonumber(data["M35"])
      batteryData["M37"] = tonumber(data["M37"])
      batteryData["M38"] = tonumber(data["M38"])
      batteryData["M39"] = tonumber(data["M39"])
      batteryData["M40"] = tonumber(data["M40"])
      batteryData["M41"] = tonumber(data["M41"])
      
      batteryData["S01"] = tonumber(data["S01"])
      batteryData["S07"] = data["S07"]
      batteryData["S08"] = tonumber(data["S08"])
      batteryData["S15"] = data["S15"]
      batteryData["S16"] = data["S16"]
      batteryData["S45"] = data["S45"]
      batteryData["S65"] = tonumber(data["S65"])
      batteryData["S66"] = data["S66"]
      batteryData["S69"] = tonumber(data["S69"])
      batteryData["S70"] = data["S70"]
      
      --Update 3.7
      batteryData["S160"] = data["S160"]
      batteryData["S161"] = data["S161"]
      batteryData["S162"] = data["S162"]
      
      local raw_json_text = JSON:encode(batteryData)

      return raw_json_text
    end
    
    
    
    local super_GetDataByIdentifier = self.GetDataByIdentifier
    self.GetDataByIdentifier = function(identifier)
      
      local data = nil
      data = self.RequestData()
      
      if data == nil then
        return nil
      end
      
      retval = data[identifier]
      
      return retval
    end
    
    
    
    local super_GetEventData = self.GetEventData
    self.GetEventData = function()
      self.Debug("GetEventData", 1)
      
      local raw_json_text = "{}"
      
      return raw_json_text
    end    
    
    
    self.RequestData = function()
      
      -- Opens a file in read mode
      file = io.open("/tmp/prosol/status_data", "r")

      -- prints the first line of the file
      -- print(file:read())
      local raw_json_text = file:read("*all")
      -- closes the opened file
      file:close()
      
      local data = JSON:decode(raw_json_text)
      
      return data
      
    end   
    
    
    
    self.Debug = function(msg, prio)
      if self.debugLevel >= prio then
        DebugLogger.LogMsg(msg)
      end
    end
    
    
    
    self.Init()
    
    
    
    return self
  end,
  
  
  new = function(debugLevel)
    return JsonDataProvider.inherit(DataProvider.new(), debugLevel)
  end
}
